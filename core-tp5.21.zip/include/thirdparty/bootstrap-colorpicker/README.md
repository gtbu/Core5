# Bootstrap Colorpicker 2.3.6

## with Bootstrap dependencies removed

Fancy and customizable color picker plugin <s>for Twitter Bootstrap</s>

## Getting started
Read the [v2 documentation here](https://itsjavi.com/bootstrap-colorpicker/v2)

## Credits
Originally written by [Stefan Petre](http://www.eyecon.ro/)
Maintained by [Javi Aguilar](http://itsjavi.com/)
Removed Bootstrap dependencies by [Juergen Krausz](http://www.grafikrausz.at/)

## Github ###
Version 2 branch on [Github](https://github.com/itsjavi/bootstrap-colorpicker/tree/v2.x)
