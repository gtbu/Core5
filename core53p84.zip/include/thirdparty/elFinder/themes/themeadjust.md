Here You find several themes. 

If You want another theme, please change the value 'moono' in main.custom.js line 172

,cssAutoLoad : [ '/themes/moono/css/theme-custom.css' ]

to material or bootstraop or any other existing theme.